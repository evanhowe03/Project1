
/**
 * 
 */
import java.util.*;
import java.io.*;

/**
 * 
 * 
 * public class Entry {
 * 
 * public int key;
 * public Seminar value;
 * 
 * public Entry(int k, Seminar v) {
 * 
 * this.key = k;
 * this.value = v;
 * 
 * }
 * 
 * }
 */
public class Entry{
    public int key;
    public Seminar value;


    // Constructors, getters, setters, etc.
    public Entry(int k, Seminar v) {
        
        this.key = k;
         this.value = v;
        
        }
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Entry entry = (Entry)o;
        return Objects.equals(key, entry.key) && Objects.equals(value,
            entry.value);
    }


    @Override
    public int hashCode() {
        return Objects.hash(key, value);
    }

}

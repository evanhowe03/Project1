import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import org.junit.Test;

public class HashTableTest extends student.TestCase {

    private HashTable table;
    private HashTable dou;
    private Seminar mySeminar;
    private Seminar empty;
    private final PrintStream originalOut = System.out;
    private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

    public void setUp() {

        System.setOut(new PrintStream(outputStreamCaptor));

        String title = "fish"; // Seminar title
        String date = "0610071600"; // Seminar date
        int length = 30; // Seminar length
        String[] keywords = { "fish", "hampster", "wheel" }; // Seminar keywords
        short x = 60; // Seminar x coord
        short y = 20; // Seminar y coord
        String desc = "Introduction to   bioinformatics and computation biology"; // Seminar
                                                                                    // description
        int cost = 300; // Seminar cost
        int id = 1; // Seminar ID
        mySeminar = new Seminar(id, title, date, length, x, y, cost, keywords, desc);
        empty = new Seminar();
        table = new HashTable(50, 50);
        dou = new HashTable(2, 1);

        // id = table.findIndex(1);
    }

    public void tearDown() {
        System.setOut(originalOut);
    }

    public void testHashSize() {
        assertEquals(50, table.getHashSize());
    }
    // tests the insert function
    @Test
    public void testInsert() throws Exception {

        table.insert(3, mySeminar);
        assertNotNull(table.searchAndReturn(3));
        assertEquals(mySeminar, table.searchAndReturn(3));

        table.insert(3, mySeminar);
        String printedText = outputStreamCaptor.toString().trim();
        assertEquals("Successfully inserted record with ID 3\n"
            + "ID: 1, Title: fish\n"
            + "Date: 0610071600, Length: 30, X: 60, Y: 20, Cost: 300\n"
            + "Description: Introduction to   bioinformatics and computation biology\n"
            + "Keywords: fish, hampster, wheel\n"
            + "Size: 125\n"
            + "\n"
            + "Insert FAILED - There is already a record with ID 3", printedText);

    }
    
    public void testFindIndex() throws Exception {
        table.insert(3, mySeminar);
        assertEquals(3, table.findIndex(3));
        
        assertEquals(-1, table.findIndex(10000));
        
        
    }

    public void testFirstHashValue() {

        assertEquals(table.firstHashValue(0), 0);
        assertEquals(table.firstHashValue(-1), -1);
        assertEquals(table.firstHashValue(59), 9);
        assertEquals(table.firstHashValue(5), 5);
    }

    public void testSecondHashValue() {
        assertEquals(1, table.secondHashValue(-5));
        assertEquals(1, table.secondHashValue(5));
        assertEquals(1, table.secondHashValue(0));
        assertEquals(41, table.secondHashValue(1000));
    }

    // Tests the delete function
    public void testDelete() throws Exception {

        table.insert(3, mySeminar);
        assertNotNull(table.searchAndReturn(3));

        table.delete(3);
        assertNull(table.searchAndReturn(3));

    }

    public void testDelete2() {
        table.delete(0);
        String printedText = outputStreamCaptor.toString().trim();
        assertEquals("Delete FAILED -- There is no record with ID 0", printedText);
    }

    public void testSearchAndReturn() throws Exception {
        table.insert(4, mySeminar);
        assertEquals(mySeminar, table.searchAndReturn(4));

        assertNull(table.searchAndReturn(7));
        assertNull(table.searchAndReturn(10000));
        // assertNull(table.searchAndReturn(-100));
    }

    public void testSearch() throws Exception {
        table.insert(4, mySeminar);

        table.search(4);
        String printedText = outputStreamCaptor.toString().trim();
        assertEquals("Successfully inserted record with ID 4\n"
            + "ID: 1, Title: fish\n"
            + "Date: 0610071600, Length: 30, X: 60, Y: 20, Cost: 300\n"
            + "Description: Introduction to   bioinformatics and computation biology\n"
            + "Keywords: fish, hampster, wheel\n"
            + "Size: 125\n"
            + "Found record with ID 4:\n"
            + "ID: 1, Title: fish\n"
            + "Date: 0610071600, Length: 30, X: 60, Y: 20, Cost: 300\n"
            + "Description: Introduction to   bioinformatics and computation biology\n"
            + "Keywords: fish, hampster, wheel", printedText);

    }

    public void testDoubleTable() throws Exception {

        assertEquals(50, table.getHashSize());
        for (int x = 0; x < 30; x++) {

            table.insert(x, mySeminar);
        }
        assertEquals(100, table.getHashSize());
        assertEquals(1, dou.getHashSize());
        // dou.insert(1, empty);
        // int x = dou.findIndex(1);
        // assertNull(dou.searchAndReturn(x));

    }

    /*
     * public void testPrintTable() {
     * 
     * table.printTable(); String printedText =
     * outputStreamCaptor.toString().trim(); assertEquals("", printedText);
     * 
     * table.insert(4, mySeminar); String text =
     * outputStreamCaptor.toString().trim();
     * assertEquals("Successfully inserted record with ID 4\n" +
     * mySeminar.toString() + "\nSize:", text);
     * 
     * String yolo = outputStreamCaptor.toString().trim();
     * assertEquals("Successfully inserted record with ID 4\n" +
     * mySeminar.toString() + "\nSize:", yolo); }
     */

    public void testPrintHashtable() {

        table.print("hashtable");

        String printedText = outputStreamCaptor.toString().trim();
        assertEquals("Hashtable:\n" + "total records: 0", printedText);

    }

    public void testPrintBlocks() {

        table.print("blocks");

        String printedText = outputStreamCaptor.toString().trim();
        assertEquals("FreeBlockList:", printedText);

    }

    public void testInsert2() throws Exception {
        table.insert(1, mySeminar);

        table.insert(1, empty);
        String printedText = outputStreamCaptor.toString().trim();
        assertEquals("Successfully inserted record with ID 1\n"
            + "ID: 1, Title: fish\n"
            + "Date: 0610071600, Length: 30, X: 60, Y: 20, Cost: 300\n"
            + "Description: Introduction to   bioinformatics and computation biology\n"
            + "Keywords: fish, hampster, wheel\n"
            + "Size: 125\n"
            + "\n"
            + "Insert FAILED - There is already a record with ID 1", printedText);

    }

    public void testSarch2() {
        table.search(2);
        String printedText = outputStreamCaptor.toString().trim();
        assertEquals("Search FAILED -- There is no record with ID 2", printedText);
        assertEquals(50, table.getHashSize());
    }

    public void testPrint2() throws Exception {
        table.insert(1, mySeminar);
        table.print("hashtable");
        String printedText = outputStreamCaptor.toString().trim();
        assertEquals("Successfully inserted record with ID 1\n"
            + "ID: 1, Title: fish\n"
            + "Date: 0610071600, Length: 30, X: 60, Y: 20, Cost: 300\n"
            + "Description: Introduction to   bioinformatics and computation biology\n"
            + "Keywords: fish, hampster, wheel\n"
            + "Size: 125\n"
            + "\n"
            + "Hashtable:\n"
            + "1: 1\n"
            + "total records: 1", printedText);

    }

}